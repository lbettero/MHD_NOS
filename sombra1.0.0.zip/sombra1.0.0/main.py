from web_scrapping import *

inicio=1000
fim=1150
site="http://www.nos.uminho.pt/History.aspx?id="

web_scrapping(site, inicio, fim)